from rest_framework import generics
from rest_framework.pagination import CursorPagination

from .serializers import TodoSerializer
from .permissions import IsOwnerOnly
from todo.models import Todo


class TodoCursorPagination(CursorPagination):
    ordering = 'id'  # Default ordering
    page_size = 2   # Set your desired page size


class TodoList(generics.ListCreateAPIView):
    permission_classes = (IsOwnerOnly,)  # added
    queryset = Todo.objects.all()
    serializer_class = TodoSerializer
    pagination_class = TodoCursorPagination

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

    # added
    def filter_queryset(self, queryset):
        queryset = queryset.filter(user=self.request.user)
        return super().filter_queryset(queryset)


class TodoDetail(generics.RetrieveUpdateDestroyAPIView):
    permission_classes = (IsOwnerOnly,)  # added
    queryset = Todo.objects.all()
    serializer_class = TodoSerializer
