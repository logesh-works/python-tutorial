import base64


def to_base46(str):
    """ Return the base64 encoding of a str """
    str_bytes = str.encode('ascii')
    base64_bytes = base64.b64encode(str_bytes)
    return base64_bytes.decode('ascii')


if __name__ == '__main__':
    username = input('Username:')
    password = input('Password:')

    output = to_base46(f"{username}:{password}")
    print(output)
